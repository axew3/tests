# My extension name

## Installation

Copy the extension to phpBB/ext/w3example/w3exampletest

Go to "ACP" > "Customise" > "Extensions" and enable the "My extension name" extension.

## License

[GNU General Public License v2](license.txt)
